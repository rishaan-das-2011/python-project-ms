"""
LESSON: 5.1 - Sprites
EXERCISE: Landscape Panic
PROBLEM: 3 of 3
"""

#### ---- SET UP ---- ####

# Import libraries, and initialize pygame
import tsk
import pygame
pygame.init()

# Create a new WINDOW
window = pygame.display.set_mode([1018, 573])

# Create the background sprites
sky = tsk.Sprite("outdoor_sky.png", 0, 0)

# Create the active sprite
star = tsk.Sprite("shooting_star.png", 0, 0)

star_moving_right = True


#### ---- MAIN LOOP ---- ####
drawing = True
while drawing:

    # --- Event Loop --- #
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            drawing = False


    # --- Check if star is offscreen --- #
    x = star.center

    if x < 0:
        x = 0
        y = 0
        star.flip_x = False
        star_moving_right = False

    elif x > 1018:
        x = 1018
        y = 0
        star.flip_x = True
        star_moving_right = True


    # --- Move star --- #
    if star_moving_right:
        star.center = (x + 5, y - 2)
    else:
        star.center = (x - 5, y - 2)


    # --- Draw the scene --- #
    sky.draw()
    star.draw()

    pygame.display.flip()