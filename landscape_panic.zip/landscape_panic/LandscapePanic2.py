"""
LESSON: 5.1 - Sprites
EXERCISE: Landscape Panic
PROBLEM: 2 of 3
"""

#### ---- SET UP ---- ####

# Import libraries, and initialize pygame
import tsk
import pygame
pygame.init()

# Create a new WINDOW
window = pygame.display.set_mode([1018, 573])

# Create the background sprite
background = tsk.Sprite("outdoor_bush_scene.jpg", 0, 0)

# Create the active sprites
chest = tsk.Sprite("chest.png", 250, 150)
bush = tsk.Sprite("bush.png", 200, 200)
sign = tsk.Sprite("sign.png", 800, 200)


#### ---- MAIN LOOP ---- ####
drawing = True
while drawing:


    # --- Event Loop --- #
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            drawing = False


    # --- Draw the background --- #
    background.draw()


    # --- Draw the scene --- #
    chest.draw()
    sign.draw()
    bush.draw()

    pygame.display.flip()